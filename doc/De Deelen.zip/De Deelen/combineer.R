library(dplyr)
library(ggplot2)
library(dplyr)
library(tidyr)

library(fileutils)

# Maak combinatieplot van stijghoogten en oppervlaktewaterstanden
# Maak bestand met dagelijkse waarden. Interpoleer met meetwaarden

### Set work directory_###
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()

#-----------------------------------------------------------
# Inlezen
#-----------------------------------------------------------

output_fldr <- "output"
if (!dir.exists(output_fldr)) {
  dir.create(output_fldr)
}

gebiedsnaam <- "De Deelen"
gw_fname <- "dino.rds"
ow_fname <- "dino.rds"

output_fname <- paste0("B11C0334_daily")

data_fldr <- file.path("..","..", "Data")
gw_fldr <- file.path(data_fldr, "Stijghoogten", gebiedsnaam, "2. Dino2txt_rds", "output"  )
ow_fldr <- file.path(data_fldr, "Oppervlaktewaterstanden", gebiedsnaam, "2. Dino2txt_rds", "output" )

gw_fname <- file.path( gw_fldr, gw_fname )
ow_fname <- file.path( ow_fldr, ow_fname )

gw <- readRDS(gw_fname)
ow <- readRDS(ow_fname)

#-----------------------------------------------------------
# Overlappende periode bepalen
#-----------------------------------------------------------

filters <- unique(gw$Filter)

starts <- sapply(filters, function(f) {
  min(gw$Date[gw$Filter == f])
})

ends <- sapply(filters, function(f) {
  max(gw$Date[gw$Filter == f])
})

tstart <- as.Date(max(starts), origin = "1970-01-01")
tend   <- as.Date(min(ends),   origin = "1970-01-01")

dates <- seq(tstart, tend, by = "day")


#-----------------------------------------------------------
# Dagelijkse interpolatie
#-----------------------------------------------------------

interp_series <- function(df, filtername, dates) {
  
  dat <- subset(df, Filter == filtername)
  
  o <- order(dat$Date)
  
  dat <- dat[o, ]
  
  approx(
    x = as.numeric(dat$Date),
    y = dat$Head,
    xout = as.numeric(dates),
    method = "linear",
    rule = 2
  )$y
}

#-----------------------------------------------------------
# Oppervlaktewater
#-----------------------------------------------------------

ow_daily <- interp_series(
  ow,
  unique(ow$Filter),
  dates
)

#-----------------------------------------------------------
# Grondwaterfilters
#-----------------------------------------------------------

df_daily <- data.frame(
  Date = dates,
  OW = ow_daily
)

for (f in filters) {
  
  df_daily[[f]] <- interp_series(
    gw,
    f,
    dates
  )
}

#-----------------------------------------------------------
# Controle
#-----------------------------------------------------------

colSums(is.na(df_daily))

#-----------------------------------------------------------
# Wegschrijven
#-----------------------------------------------------------

# omzetting van cm NAP naar m NAP
df_daily[ , -1] <- df_daily[ , -1] / 100

fname <- file.path(output_fldr, paste0(output_fname,".txt"))
write.table(
  df_daily,
  fname,
  sep = "\t",
  quote = TRUE,
  row.names = FALSE
)

#-----------------------------------------------------------
# Plot
#-----------------------------------------------------------

df_long <- pivot_longer(
  df_daily,
  cols = -Date,
  names_to = "Serie",
  values_to = "Head"
)

ggplot(
  df_long,
  aes(Date, Head, colour = Serie)
) +
  geom_line() +
  theme_bw() +
  labs(
    x = "",
    y = "Stand (m NAP)"
  )+
  theme_bw(base_size = 15)
fname <- file.path(output_fldr, paste0(output_fname,".png"))
ggsave(paste0(fname,".png"))
