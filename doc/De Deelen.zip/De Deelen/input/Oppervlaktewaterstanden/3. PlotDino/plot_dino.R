# plot dinoloket data die verwerkt is met dino.R.

library(dplyr)
library(rstudioapi)
library(magrittr)
library(lubridate)
library(ggplot2)

### Set work directory_###
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()

### Global parameters
input_fldr <- file.path("..","2. Dino2txt_rds", "output") 
input_fname <-  file.path(input_fldr, "dino.rds")
variants <- c("P11D0003") 
output_fldr <- "./output"

#########################################################################################

###_Function definitions_###

# read timeserie from *.rds file.
# create dataframe with time series specified by the names in "variants" (character vector) from list x with time series.
create_df <- function( variants, fname) {
  df <- fname |> readRDS() |> dplyr::filter(Filter %in% variants)
  df$Datetime <- lubridate::make_datetime(year=df$Jaar, month=lubridate::month(df$Date), day=lubridate::day(df$Date), hour=df$Uur)
  df$Filter %<>% factor(levels=variants)
  df$Value <- df$Head
  return(df)
}

# plot timeseries in data frame df
plot_dino <- function(df, output_fldr_name, laby="Stijghoogte (m+NAP)" ) {
  df$Value %<>% round(.,2)
  ggplot(data=df, aes(x = Datetime, y = Value, colour = Filter)) +
    #geom_point() +
    geom_line() +
    labs(y = laby,
         x = "Tijd") +
    theme_bw(base_size = 15)
  fname <-  df$Filter %>% unique() %>% paste(collapse="_") %>% paste0(".png")
  fname %>% file.path(output_fldr, .) %>% ggsave()
}

#########################################################################################

### main ###
if (!dir.exists(output_fldr)) {
  dir.create(output_fldr)
}

# Create plots
df <- create_df(variants, input_fname) |> plot_dino( output_fldr, laby="Waterstand (m+NAP)" )




