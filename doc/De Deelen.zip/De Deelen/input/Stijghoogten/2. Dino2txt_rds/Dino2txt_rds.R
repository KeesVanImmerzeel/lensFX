### Lees csv bestand(en) uit Dinoloket met stijghoogten en 
### schrijf genormaliseerd txt en RDS bestand weg met alle waarnemeningen.

library(dplyr)
library(rstudioapi)
library(lubridate)
library( magrittr)
library(stringr)
library(fileutils)
library(ggplot2)

### Set work directory_###
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()

###_Select input folder name and output folder name_###
# Folder with Dino *_1.csv files
input_fldr_name <- file.path("..", "1. Download")
# Output folder for result files 
output_fldr_name <- "output"

fname_output <- file.path(output_fldr_name, "dino")

#########################################################################################

###_Function definitions_###

# Read head from Dinoloket groundwater heads csv file into data frame.
get_heads_df <- function(fname, grep_pattern='^"Locatie","Filternummer","Peildatum","Stand \\(cm t\\.o\\.v\\. MP\\)"') {
  
  # read file
  lines <- readLines(fname, warn = FALSE)
  
  # locate header of measurements table
  ihead <- grep(
    grep_pattern,
    lines
  )
  
  if (length(ihead) == 0) {
    stop("Measurement table not found.")
  }
  
  # use last occurrence (first is metadata table)
  ihead <- tail(ihead, 1)
  
  # determine end of table
  iend <- seq(ihead + 1, length(lines))
  iend <- iend[
    grepl('^,+$', lines[iend]) |
      lines[iend] == ""
  ]
  
  iend <- if (length(iend) > 0) min(iend) - 1 else length(lines)
  
  # read measurement table
  txt <- paste(lines[ihead:iend], collapse = "\n")
  
  dat <- read.csv(
    text = txt,
    header = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  
  # extract variables
  dates <- as.Date(dat$Peildatum, format = "%d-%m-%Y")
  heads <- as.numeric(dat[["Stand (cm t.o.v NAP)"]])
  
  # remove rows with missing heads
  keep <- complete.cases(dates, heads)
  
  dates <- dates[keep]
  heads <- heads[keep]
  
  # construct remaining fields
  uur <- rep(0, length(dates))
  years <- as.integer(format(dates, "%Y"))
  
  names_strings <- paste0(
    dat$Locatie[keep],
    "_",
    dat$Filternummer[keep]
  )
  
  df <- data.frame(
    Date   = dates,
    Uur    = uur,
    Head   = heads,
    Jaar   = years,
    Filter = names_strings,
    stringsAsFactors = FALSE
  )
  
  df
}

#########################################################################################

# Retreive all *_1.csv filenames
fnames <- list.files(
  path = input_fldr_name,
  pattern = glob2rx("*.csv"),
  full.names = TRUE,
  recursive = TRUE,
  ignore.case = TRUE
) %>% as.matrix()

# Create data.frame "all_heads" with head observations
all_heads <- suppressWarnings( apply(fnames, MARGIN = 1, get_heads_df) %>% bind_rows() )

# Write data.frame tot text file and rds-file.
write.table(all_heads,paste0(fname_output,".txt"),row.names=FALSE, dec = ".",  sep = "\t")
saveRDS(all_heads,paste0(fname_output,".rds"))

#ggplot(all_heads, aes(x = Date, y = Head, colour = Filter, group = Filter)) +
#  geom_line(linewidth = 0.6) +
#  geom_point(size = 1) +
#  labs(
#    x = "Date",
#    y = "Head (cm t.o.v. NAP)",
#    colour = "Filter"
#  ) +
#  theme_bw()
